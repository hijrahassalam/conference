<div class="col-md-8 col-md-offset-2" style="padding-left:0px">
				<a href="<?php echo base_url()?>"><img src="<?php echo base_url('uploads/logo.png')?>" style="width:100%"></a>
<br/>
<div style="float:right">
	<form method="POST">
		<select name="bahasa" id="bahasa" class="form-control">
			<option value="eng" selected>English</option>
		</select>
	</form>
</div>
<br/><br/>
			</div>