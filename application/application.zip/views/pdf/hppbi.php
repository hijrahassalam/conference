<page></page>
<table width="100%;">
	<tr>
		<td>
			<img src="img/depan.jpeg" style="width: 320px;height:198px" />
			<div style="    position: absolute;    top: 66px;    left: 90px;    font-size: 8px;"><b> <?php echo hexToStr($id) ?></b></div>
			<div style="position: absolute;top: 78px;left: 90px;font-size: 8px;"> <b><?php echo hexToStr($no) ?></b></div>
			<div style="position: absolute;top: 89px;left: 90px;font-size: 8px;margin-right:3px;"><b><?php echo hexToStr($ins) ?></b></div>
			<div style="position: absolute;top: 105px;left: 20px;font-size: 8px;"><?php echo (hexToStr($photo)!="") ? '<img src="'.hexToStr($photo).'" style="width:40px;height:50px">' : '' ?></div>
			<div style="position: absolute;top: 160px;left: 20px;font-size: 8px;"><b>Masa Berlaku : <?php echo hexToStr($aktif) ?></b></div>
		</td><!-- 
		<td  width="50%" ><img src="<?php echo base_url();?>img/hppbi_belakang.jpg" style="width: 315px; height:210px;" /></td> -->
	</tr>
</table>
<page></page>
<table width="100%;">
	<tr>
		<td>
			<!-- <img src="<?php echo base_url();?>img/hppbi_depan.jpg" style="width: 320px;height:198px" /> -->
			<img src="img/belakang.jpeg" style="width: 320px; height:198px;" />
<!-- 			<div style="    position: absolute;    top: 66px;    left: 103px;    font-size: 10px;"> Adriyanto Prasetyo</div>
			<div style="position: absolute;top: 78px;left: 103px;font-size: 10px;"> K3513003</div>
			<div style="position: absolute;top: 89px;left: 103px;font-size: 10px;margin-right:3px;">Jalan Maju Mundur No 1234656wefggwegwegeg<br/>aadasfafuahfu</div>
			
			<div style="position: absolute;top: 165px;left: 77px;font-size: 10px;">20-12-2016</div> -->
		</td><!-- 
		<td  width="50%" ><img src="<?php echo base_url();?>img/hppbi_belakang.jpg" style="width: 315px; height:210px;" /></td> -->
	</tr>
</table>